/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Islam
 */

import java.sql.*;
import javax.swing.*;

public class DatabaseConnection {
    
    public static final String URL = "jdbc:mysql://localhost/library_management";
    
    public static Connection ConnectorDb()
    {
        try
        {
            Connection connection = DriverManager.getConnection(URL,"root","");
            
            return connection;
        }
        catch(Exception error)
        {
            JOptionPane.showMessageDialog(null, error);
            
            return null;
        }
    }
    
}
